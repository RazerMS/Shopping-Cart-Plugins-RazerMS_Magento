<?php

namespace RazerPay\Payment\Exception;

class CaptureCreditAuthPaymentException extends \Exception
{
}

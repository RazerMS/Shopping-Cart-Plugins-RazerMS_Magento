<?php

namespace RazerPay\Payment\Exception;

class SalesOrderPaymentHandledException extends \Exception
{
}

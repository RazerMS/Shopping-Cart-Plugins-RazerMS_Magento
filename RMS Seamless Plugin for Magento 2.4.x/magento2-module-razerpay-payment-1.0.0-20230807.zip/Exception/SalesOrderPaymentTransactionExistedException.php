<?php

namespace RazerPay\Payment\Exception;

class SalesOrderPaymentTransactionExistedException extends \Exception
{
}

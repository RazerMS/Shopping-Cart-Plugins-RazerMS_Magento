<?php

namespace RazerPay\Payment\Logger;

class Logger extends \Magento\Framework\Logger\Monolog
{

}

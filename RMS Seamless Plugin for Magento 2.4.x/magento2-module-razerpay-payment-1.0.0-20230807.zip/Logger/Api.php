<?php

namespace RazerPay\Payment\Logger;

use Magento\Framework\Logger\Monolog;

class Api extends Monolog
{
}

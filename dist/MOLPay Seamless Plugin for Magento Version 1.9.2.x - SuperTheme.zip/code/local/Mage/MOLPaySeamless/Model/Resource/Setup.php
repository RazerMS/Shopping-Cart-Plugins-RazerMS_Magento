<?php
/**
MOLPay Sdn Bhd

Description: Initiate the class
**/

class Mage_MOLPaySeamless_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup {

}

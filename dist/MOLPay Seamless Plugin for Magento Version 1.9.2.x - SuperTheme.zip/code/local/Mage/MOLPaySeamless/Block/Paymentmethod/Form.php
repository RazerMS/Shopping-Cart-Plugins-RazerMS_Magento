<?php
class Mage_MOLPaySeamless_Block_PaymentMethod_Form extends Mage_Payment_Block_Form {
    
    
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('MOLPaySeamless/form/payment.phtml');
    }
    
}
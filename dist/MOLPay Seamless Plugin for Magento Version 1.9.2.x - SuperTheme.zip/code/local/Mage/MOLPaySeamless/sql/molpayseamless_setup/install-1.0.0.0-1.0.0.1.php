<?php
/** 
MOLPay Sdn Bhd
Date Created: 31-Jan-2017
Description: Initial setup, add column name molpay_channel_name in table sales_flat_order_payment. 
             Purpose to trace channel selected by customer on checkout payment page.
**/

$installer = $this;
$installer->startSetup();

$installer->getConnection()
->addColumn($installer->getTable('sales/quote_payment'),'molpayseamless_payment_channel', array(
    'type'      => Varien_Db_Ddl_Table::TYPE_TEXT,
    'nullable'  => true,
    'length'    => 255,
    'after'     => 'method', // column name to insert new column after
    'comment'   => 'Channel name'
    ));
    
$installer->getConnection()
->addColumn($installer->getTable('sales/order_payment'),'molpayseamless_payment_channel', array(
    'type'      => Varien_Db_Ddl_Table::TYPE_TEXT,
    'nullable'  => true,
    'length'    => 255,
    'after'     => 'method', // column name to insert new column after
    'comment'   => 'Channel name'
    ));

$installer->endSetup();
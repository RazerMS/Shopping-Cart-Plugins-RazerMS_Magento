## Synopsis
An extension to add integration with Payment Gateway.
This payment method can be restricted to work only with specific Shipping method.

## Motivation
This is one of a collection of examples to demonstrate the features of Magento 2.  The intent of this sample is to demonstrate how to create own Payment Gateway integration

## Contributors
Magento Core team

## License
[Open Source License](LICENSE.txt)

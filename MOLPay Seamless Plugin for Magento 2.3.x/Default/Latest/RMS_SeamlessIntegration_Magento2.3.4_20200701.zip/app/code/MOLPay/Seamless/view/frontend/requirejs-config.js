/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            molpayseamlessdeco: 'https://onlinepayment.com.my/RMS/API/seamless/latest/js/MOLPay_seamless.deco.js?v=9',
            molpayseamlessdecosandbox: 'https://sandbox.merchant.razer.com/RMS/API/seamless/latest/js/MOLPay_seamless.deco.js?v=9'
        }
    }
};

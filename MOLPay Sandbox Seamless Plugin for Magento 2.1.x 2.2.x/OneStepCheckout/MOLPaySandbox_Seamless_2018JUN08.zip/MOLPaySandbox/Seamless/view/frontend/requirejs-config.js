/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.

 Sample : molpaypickchannel: "MOLPaySandbox_Seamless/js/pickchannel
 */

var config = {
    map: {
        '*': {
            molpaysandboxseamlessdeco: 'https://sandbox.molpay.com/MOLPay/API/seamless/latest/js/MOLPay_seamless.deco.js?v=9'
        }
    }
};
